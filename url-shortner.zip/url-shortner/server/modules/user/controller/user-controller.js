import userService from "../service/user-service.js";

export class UserController {
  async register(req, res) {
    const body = req.body;

    try {
      const user = await userService.registerService(body);
      res.status(201).json({ message: "User Register Success", user: user });
    } catch (err) {
      res.status(501).json({ mssage: err.message });
    }
  }

  async login(req, res) {
    const body = req.body;
    try {
      const user = await userService.loginService(body);
      res.status(201).json({ message: "User Login Success", user: user });
    } catch (err) {
      res.status(500).json({ message: err.message || "Error in Login" });
    }
  }
}

export default new UserController();
