import bcrypt from "bcrypt";

export const hashPassword = (rawPassword) => {
  const salt = bcrypt.genSaltSync(10);
  const hashed = bcrypt.hashSync(rawPassword, salt);
  return hashed;
};

export const comparePassword = (rawPassword, hashed) => {
  return bcrypt.compareSync(rawPassword, hashed);
};
