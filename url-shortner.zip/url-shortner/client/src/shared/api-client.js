import axios from "axios";

export const api = axios.create({
  baseURL: "http://localhost:1234/v1",
  timeout: 2000,
  headers: {
    "Content-Type": "application/json",
  },
});

export async function registerUser(data) {
  console.log(import.meta.env.BASE_URL, "askjhjsa");
  try {
    const response = await api.post("/user", data);
    return response.data;
  } catch (error) {
    if (error.response) {
      // Server responded with error status
      throw error.response.data.message || "Registration failed";
    } else if (error.request) {
      // Request made but no response
      throw "Network error. Please try again.";
    } else {
      // Something else happened
      throw "Something went wrong. Please try again.";
    }
  }
}
