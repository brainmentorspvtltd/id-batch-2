import {
  Box,
  Card,
  Heading,
  Text,
  TextField,
  Button,
  Flex,
} from "@radix-ui/themes";
import { useNavigate } from "react-router-dom";
const LoginPage = () => {
  const navigate = useNavigate();
  return (
    <Box maxWidth="400px" mx="auto" mt="6">
      <Card size="3">
        <Heading size="6" mb="4" align="center">
          Login
        </Heading>

        <Box mb="3">
          <Button variant="soft" size="2" onClick={() => navigate("/")}>
            ← Back to Home
          </Button>
        </Box>

        <Box mb="3">
          <Text as="label" size="2" weight="medium" mb="1">
            Email
          </Text>
          <TextField.Root type="email" placeholder="Enter your email" />
        </Box>

        <Box mb="4">
          <Text as="label" size="2" weight="medium" mb="1">
            Password
          </Text>
          <TextField.Root type="password" placeholder="Enter your password" />
        </Box>

        <Flex gap="3">
          <Button size="3" style={{ flex: 1 }}>
            Login
          </Button>
          <Button size="3" variant="soft" color="gray" style={{ flex: 1 }}>
            Clear
          </Button>
        </Flex>
      </Card>
    </Box>
  );
};

export default LoginPage;
