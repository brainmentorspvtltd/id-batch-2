import {
  Box,
  Card,
  Heading,
  Text,
  TextField,
  Button,
  Flex,
} from "@radix-ui/themes";
import { useState } from "react";
import { useNavigate } from "react-router-dom";
import { registerUser } from "../../../shared/api-client.js";
const RegisterPage = () => {
  const [userName, setUserName] = useState();
  const [email, setEmail] = useState();
  const [password, setPassword] = useState();
  const navigate = useNavigate();

  const changeUserName = (e) => {
    setUserName(e.target.value);
    console.log(userName);
  };

  const changeEmail = (e) => {
    setEmail(e.target.value);
  };
  const changePassword = (e) => {
    setPassword(e.target.value);
  };

  const handleClear = () => {
    setPassword("");
    setUserName("");
    setEmail("");
  };

  const handleSubmit = async () => {
    const registerObj = { password, userName, email };
    console.log(registerObj);
    const success = await registerUser(registerObj);
    if (success) {
      setTimeout(() => {
        navigate("/login");
      }, 1000);
    }
  };
  return (
    <Box maxWidth="400px" mx="auto" mt="6">
      <Card size="3">
        <Heading size="6" mb="4" align="center">
          Register
        </Heading>

        <Box mb="3">
          <Button variant="soft" size="2" onClick={() => navigate("/")}>
            ← Back to Home
          </Button>
        </Box>
        <Box mb="3">
          <Text as="label" size="2" weight="medium" mb="1">
            User Name
          </Text>
          <TextField.Root
            value={userName}
            type="email"
            placeholder="Enter your Name"
            onChange={changeUserName}
          />
        </Box>

        <Box mb="3">
          <Text as="label" size="2" weight="medium" mb="1">
            Email
          </Text>
          <TextField.Root
            value={email}
            type="email"
            placeholder="Enter your email"
            onChange={changeEmail}
          />
        </Box>

        <Box mb="4">
          <Text as="label" size="2" weight="medium" mb="1">
            Password
          </Text>
          <TextField.Root
            value={password}
            type="password"
            placeholder="Enter your password"
            onChange={changePassword}
          />
        </Box>

        <Flex gap="3">
          <Button size="3" style={{ flex: 1 }} onClick={handleSubmit}>
            Register
          </Button>
          <Button
            size="3"
            variant="soft"
            color="gray"
            style={{ flex: 1 }}
            onClick={handleClear}
          >
            Clear
          </Button>
        </Flex>
      </Card>
    </Box>
  );
};

export default RegisterPage;
