import "./App.css";
import { BrowserRouter, Route, Routes } from "react-router-dom";
import HomePage from "./modules/home/pages/HomePage.jsx";
import LoginPage from "./modules/user/pages/LoginPage.jsx";
import RegisterPage from "./modules/user/pages/RegisterPage.jsx";

function App() {
  return (
    <>
      <BrowserRouter>
        <Routes>
          <Route path="/" element={<HomePage />} />
          <Route path="/login" element={<LoginPage />} />
          <Route path="/register" element={<RegisterPage />} />
        </Routes>
      </BrowserRouter>
    </>
  );
}

export default App;
