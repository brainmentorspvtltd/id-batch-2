import { app } from "./app.js";
import dotenv from "dotenv";
import { createDbConnection } from "./db/connection.js";

dotenv.config();

app.listen(process.env.PORT, () => {
  console.log("Server is Running");
  createDbConnection();
});
