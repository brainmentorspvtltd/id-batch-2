import mongoose from "mongoose";

export async function createDbConnection() {
  try {
    await mongoose.connect(process.env.MONGODB_URI);
    console.log("Connected To DB");
  } catch (err) {
    console.log("Error in DB COnnection", err);
  }
}
