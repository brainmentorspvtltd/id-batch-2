import { User } from "../../../db/schema/User.js";
import { v4 as uuidv4 } from "uuid";
import { comparePassword, hashPassword } from "../util/password-util.js";
import jwt from "jsonwebtoken";
import { generateToken } from "../util/jwt-util.js";

export class UserService {
  async registerService(body) {
    const { email, password, userName } = body;
    const user = await User.findOne({ email });

    console.log(user);
    if (user) {
      throw new Error("User Already Exists");
    }
    try {
      const id = uuidv4();
      const hashed = hashPassword(password);
      const newUser = new User({
        userId: id,
        email: email,
        password: hashed,
        userName: userName,
      });
      console.log(user);
      const userDoc = await newUser.save();
      return userDoc;
    } catch (err) {
      throw err;
    }
  }

  async loginService(body) {
    const { email, password } = body;
    console.log(email, password);
    const user = await User.findOne({ email });
    console.log(user);
    if (!user) {
      console.log();
      throw new Error("Please Register");
    }
    const isMatched = comparePassword(password, user.password);
    if (!isMatched) {
      throw new Error("Invalid Email or Password");
    }
    console.log(isMatched, "Password mathed");

    const token = generateToken(user.userId, user.email);
    console.log("Token is ", token);
    return { user: user, token: token };
  }
}

export default new UserService();
