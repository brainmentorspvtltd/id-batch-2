import express from "express";
import userController from "../controller/user-controller.js";

export const userRouter = express.Router();

userRouter.get("/", (req, res) => {
  res.send("The server is Running APi Working");
});

userRouter.post("/", userController.register);
userRouter.post("/login", userController.login);
