import "./App.css";
import { BrowserRouter, Route, Routes } from "react-router-dom";
import HomePage from "./modules/home/pages/HomePage.jsx";
import LoginPage from "./modules/user/pages/LoginPage.jsx";
import RegisterPage from "./modules/user/pages/RegisterPage.jsx";
import UrlDashboard from "./modules/url/pages/UrlDashboard.jsx";

function App() {
  return (
    <>
      <BrowserRouter>
        <Routes>
          <Route path="/" element={<HomePage />} />
          <Route path="/login" element={<LoginPage />} />
          <Route path="/register" element={<RegisterPage />} />
          <Route path="/url-dashboard" element={<UrlDashboard />} />
        </Routes>
      </BrowserRouter>
    </>
  );
}

export default App;
