import React from "react";

const UrlDashboard = () => {
  return <div>UrlDashboard</div>;
};

export default UrlDashboard;
