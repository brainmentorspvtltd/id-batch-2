import {
  Avatar,
  Box,
  Button,
  Card,
  Flex,
  Heading,
  Text,
  Theme,
} from "@radix-ui/themes";
import { Link, useNavigate } from "react-router-dom";

const HomePage = () => {
  const navigate = useNavigate();
  return (
    <>
      <Flex height={"100vh"} justify={"center"} align={"center"}>
        <Box maxWidth="500px" mx="auto">
          <Card size="4">
            <Heading size="8" mb="2" align="center">
              URL Shortener Project
            </Heading>
            <Heading size="4" mb="4" align="center">
              Welcome
            </Heading>

            <Flex direction="column" gap="4">
              <Button size="4" onClick={() => navigate("/login")}>
                Go to Login
              </Button>
              <Button
                size="4"
                variant="soft"
                onClick={() => navigate("/register")}
              >
                Go to Register
              </Button>
            </Flex>
          </Card>
        </Box>
      </Flex>
    </>
  );
};

export default HomePage;
