import {
  Box,
  Card,
  Heading,
  Text,
  TextField,
  Button,
  Flex,
} from "@radix-ui/themes";
import { useNavigate } from "react-router-dom";
import { loginUser } from "../../../shared/api-client.js";
import { useState } from "react";
const LoginPage = () => {
  const [email, setEmail] = useState();
  const [password, setPassword] = useState();
  const navigate = useNavigate();

  const changeEmail = (e) => {
    setEmail(e.target.value);
  };
  const changePassword = (e) => {
    setPassword(e.target.value);
  };

  const handleClear = () => {
    setPassword("");
    setEmail("");
  };

  const handleSubmit = async () => {
    const registerObj = { password, email };
    console.log(registerObj);
    const success = await loginUser(registerObj);
    if (success) {
      setTimeout(() => {
        navigate("/url-dashboard");
      }, 1000);
    }
  };
  return (
    <Box maxWidth="400px" mx="auto" mt="6">
      <Card size="3">
        <Heading size="6" mb="4" align="center">
          Login
        </Heading>

        <Box mb="3">
          <Button variant="soft" size="2" onClick={() => navigate("/")}>
            ← Back to Home
          </Button>
        </Box>

        <Box mb="3">
          <Text as="label" size="2" weight="medium" mb="1">
            Email
          </Text>
          <TextField.Root
            value={email}
            type="email"
            placeholder="Enter your email"
            onChange={changeEmail}
          />
        </Box>

        <Box mb="4">
          <Text as="label" size="2" weight="medium" mb="1">
            Password
          </Text>
          <TextField.Root
            value={password}
            type="password"
            placeholder="Enter your password"
            onChange={changePassword}
          />
        </Box>

        <Flex gap="3">
          <Button size="3" style={{ flex: 1 }} onClick={handleSubmit}>
            Login
          </Button>
          <Button
            size="3"
            variant="soft"
            color="gray"
            style={{ flex: 1 }}
            onClick={handleClear}
          >
            Clear
          </Button>
        </Flex>
      </Card>
    </Box>
  );
};

export default LoginPage;
